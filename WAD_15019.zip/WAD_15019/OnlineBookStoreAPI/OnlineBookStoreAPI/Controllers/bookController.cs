﻿using System.Transactions;
using Microsoft.AspNetCore.Mvc;
using OnlineBookStoreAPI.Models;
using OnlineBookStoreAPI.Repositories;

namespace OnlineBookStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class bookController : ControllerBase
    {
        private readonly IBookRepository __bookRepository;

        public bookController(IBookRepository bookRepository)
        {
            __bookRepository = bookRepository;

        }

        // GET: 
        [HttpGet]
        public IActionResult Get() 
        {
            return new OkObjectResult(__bookRepository.RetrieveAll());
        }

        // GET: 
        [HttpGet("{id}", Name ="GetBookByID")]
        public IActionResult GetBookById(int ID) 
        {
            return new OkObjectResult(__bookRepository.RetrieveByID(ID));
        }

        // PUT: 
        [HttpPut("{id}")]
        public IActionResult UpdateBook([FromBody] book oBook) 
        {
            if (oBook != null) 
            {
                using (var scope = new TransactionScope()) 
                {
                    __bookRepository.UpdateBook(oBook);
                    scope.Complete();
                    return new OkResult();
                }
            }
            return new NoContentResult();
        }

        // POST: 

        [HttpPost]
        public IActionResult CreateNewBook(book oBook) 
        {
            using (var scope = new TransactionScope())
            {
                __bookRepository.CreateNewBook(oBook);
                scope.Complete();
                return CreatedAtAction(nameof(Get), new { ID = oBook.Id }, oBook);
            }

        }

        // DELETE: 
        [HttpDelete("{id}")]
        public IActionResult DeleteBook(int ID) 
        {

            __bookRepository.DeleteBookByID(ID);
            return new OkResult();
        }
    }
}
