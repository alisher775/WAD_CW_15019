﻿using Microsoft.EntityFrameworkCore;
using OnlineBookStoreAPI.Models;

namespace OnlineBookStoreAPI.DAL
{
    public class BookDbContext:DbContext
    {
        public BookDbContext(DbContextOptions<BookDbContext> options):base(options)
        {
            Database.EnsureCreated();
        }
        public DbSet<book> Book { get; set; }
    }
}
