﻿using System;
using System.Collections.Generic;
using OnlineBookStoreAPI.Models;
using OnlineBookStoreAPI.DAL;
using System.Linq;

namespace OnlineBookStoreAPI.Repositories
{
    public class bookRepository : IBookRepository
    {
        // initializing dbcontext public to private
        private readonly BookDbContext __dbContext;
        public bookRepository(BookDbContext dbContext)
        {
            __dbContext = dbContext;
        }

        // Save function implemented later
        public void Save() 
        {
            __dbContext.SaveChanges();
        }

        public void CreateNewBook(book oBook)
        {
            __dbContext.Add(oBook);
            Save();

        }

        public void DeleteBookByID(int BookID)
        {
            var foundBook = __dbContext.Book.Find(BookID);
            __dbContext.Book.Remove(foundBook);
            Save();
        }

        public IEnumerable<book> RetrieveAll()
        {
            return __dbContext.Book.ToList();
        }

        public book RetrieveByID(int BookID)
        {
            
            return __dbContext.Book.Find(BookID);
        }

        public void UpdateBook(book oBook)
        {
            __dbContext.Entry(oBook).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            Save();
        }
    }
}
