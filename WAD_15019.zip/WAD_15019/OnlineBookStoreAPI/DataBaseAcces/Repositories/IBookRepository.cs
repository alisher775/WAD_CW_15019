﻿using System.Collections.Generic;
using OnlineBookStoreAPI.Models;

namespace OnlineBookStoreAPI.Repositories
{
    public interface IBookRepository
    {
       
        void CreateNewBook(book oBook);

      
        IEnumerable<book> RetrieveAll();
        
        
        book RetrieveByID(int BookId);

      
        void DeleteBookByID(int BookId);
        
        
        void UpdateBook(book oBook);

    }
}
