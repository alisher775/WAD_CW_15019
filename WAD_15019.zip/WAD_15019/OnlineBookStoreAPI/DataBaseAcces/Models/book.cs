﻿using System;
using System.ComponentModel.DataAnnotations;

namespace OnlineBookStoreAPI.Models
{
    public class book
    {
        public int Id { get; set; }

        [Required]
        public string BookName { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public decimal Price { get; set; }

        [Required]
        public string Ganre{ get; set; }

        [Required]
        public decimal Quantity { get; set; }

    }
}
